#include <QApplication>
#include <QMainWindow>
#include <QTabWidget>
#include <QWidget>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QGridLayout>
#include <QLabel>
#include <QPushButton>
#include <QLineEdit>
#include <QSpinBox>
#include <QComboBox>
#include <QTableWidget>
#include <QHeaderView>
#include <QMessageBox>
#include <QFile>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>
#include <QTextEdit>
#include <QGroupBox>
#include <QFormLayout>
#include <QDateTime>
#include <QSplitter>
#include <QFrame>
#include <QMap>
#include <QQueue>
#include <QSet>
#include <algorithm>
#include <limits>

struct Zone {
    QString name;
    int severity = 1;
    int people = 0;
    int foodNeed = 0;
    int waterNeed = 0;
    int medicalNeed = 0;
    int foodAllocated = 0;
    int waterAllocated = 0;
    int medicalAllocated = 0;
};

struct Road {
    QString from;
    QString to;
    int distance = 1;
    bool blocked = false;
};

class MainWindow : public QMainWindow {
    Q_OBJECT
public:
    MainWindow() {
        setWindowTitle("ARES | Disaster Intelligence & Emergency Resource Control");
        resize(1180, 760);
        setMinimumSize(980, 650);
        buildUi();
        loadData();
        refreshAll();
        applyStyle();
    }

private:
    QVector<Zone> zones;
    QVector<Road> roads;
    int foodStock = 1000, waterStock = 1500, medicalStock = 300;

    QTabWidget *tabs = nullptr;
    QLabel *zoneMetric, *peopleMetric, *foodMetric, *waterMetric;
    QTableWidget *zoneTable, *allocationTable, *roadTable;
    QLineEdit *zoneName, *roadFrom, *roadTo;
    QSpinBox *severity, *people, *foodNeed, *waterNeed, *medicalNeed;
    QSpinBox *foodInput, *waterInput, *medicalInput;
    QSpinBox *roadDistance;
    QComboBox *routeFrom, *routeTo;
    QTextEdit *routeOutput, *reportOutput;

    QString dataPath() const { return QCoreApplication::applicationDirPath() + "/ares_data.json"; }

    QLabel *metricCard(const QString &caption, QLabel **value) {
        auto *box = new QFrame;
        box->setObjectName("metricCard");
        auto *layout = new QVBoxLayout(box);
        auto *small = new QLabel(caption);
        small->setObjectName("metricCaption");
        *value = new QLabel("0");
        (*value)->setObjectName("metricValue");
        layout->addWidget(small);
        layout->addWidget(*value);
        return new QLabel; // card is added separately through parent lookup not used
    }

    QWidget *makeMetric(const QString &caption, QLabel **value) {
        auto *box = new QFrame;
        box->setObjectName("metricCard");
        auto *layout = new QVBoxLayout(box);
        auto *small = new QLabel(caption);
        small->setObjectName("metricCaption");
        *value = new QLabel("0");
        (*value)->setObjectName("metricValue");
        layout->addWidget(small);
        layout->addWidget(*value);
        return box;
    }

    QPushButton *button(const QString &text, const QString &objectName = "actionButton") {
        auto *b = new QPushButton(text);
        b->setObjectName(objectName);
        b->setCursor(Qt::PointingHandCursor);
        return b;
    }

    void buildUi() {
        auto *central = new QWidget;
        auto *root = new QVBoxLayout(central);
        auto *header = new QHBoxLayout;
        auto *brand = new QLabel("ARES");
        brand->setObjectName("brand");
        auto *subtitle = new QLabel("DISASTER INTELLIGENCE & EMERGENCY RESOURCE CONTROL");
        subtitle->setObjectName("subtitle");
        header->addWidget(brand);
        header->addSpacing(14);
        header->addWidget(subtitle);
        header->addStretch();
        auto *status = new QLabel("● SYSTEM ONLINE");
        status->setObjectName("online");
        header->addWidget(status);
        root->addLayout(header);

        tabs = new QTabWidget;
        tabs->addTab(buildOverview(), "Overview");
        tabs->addTab(buildMonitoring(), "01  Disaster Monitoring");
        tabs->addTab(buildResources(), "02  Resource Allocation");
        tabs->addTab(buildRoutes(), "03  Route Optimization");
        tabs->addTab(buildReports(), "Reports");
        root->addWidget(tabs);
        setCentralWidget(central);
    }

    QWidget *buildOverview() {
        auto *w = new QWidget;
        auto *l = new QVBoxLayout(w);
        auto *intro = new QLabel("Emergency Operations Dashboard");
        intro->setObjectName("sectionTitle");
        l->addWidget(intro);
        auto *cards = new QGridLayout;
        cards->addWidget(makeMetric("REGISTERED DISASTER ZONES", &zoneMetric), 0, 0);
        cards->addWidget(makeMetric("PEOPLE AFFECTED", &peopleMetric), 0, 1);
        cards->addWidget(makeMetric("FOOD PACKETS AVAILABLE", &foodMetric), 0, 2);
        cards->addWidget(makeMetric("WATER UNITS AVAILABLE", &waterMetric), 0, 3);
        l->addLayout(cards);

        auto *hint = new QLabel("Live calculations use the zones, needs, inventory and roads entered in the modules. Changes are saved locally.");
        hint->setObjectName("hint");
        hint->setWordWrap(true);
        l->addWidget(hint);

        auto *heading = new QLabel("Current Zone Situation");
        heading->setObjectName("subTitle");
        l->addWidget(heading);
        zoneTable = new QTableWidget(0, 7);
        zoneTable->setHorizontalHeaderLabels({"Zone", "Severity", "People", "Food Need", "Water Need", "Medical Need", "Priority Score"});
        configureTable(zoneTable);
        l->addWidget(zoneTable);
        auto *refresh = button("Refresh Dashboard");
        connect(refresh, &QPushButton::clicked, this, &MainWindow::refreshAll);
        l->addWidget(refresh, 0, Qt::AlignRight);
        return w;
    }

    QWidget *buildMonitoring() {
        auto *w = new QWidget;
        auto *l = new QVBoxLayout(w);
        auto *title = new QLabel("Disaster Monitoring & Predictive Analysis");
        title->setObjectName("sectionTitle");
        l->addWidget(title);

        auto *group = new QGroupBox("Register affected location");
        auto *form = new QGridLayout(group);
        zoneName = new QLineEdit; zoneName->setPlaceholderText("e.g. North Colony");
        severity = new QSpinBox; severity->setRange(1, 5); severity->setValue(3);
        people = new QSpinBox; people->setRange(0, 10000000); people->setValue(250);
        foodNeed = new QSpinBox; foodNeed->setRange(0, 10000000); foodNeed->setValue(300);
        waterNeed = new QSpinBox; waterNeed->setRange(0, 10000000); waterNeed->setValue(300);
        medicalNeed = new QSpinBox; medicalNeed->setRange(0, 10000000); medicalNeed->setValue(50);
        form->addWidget(new QLabel("Location name"), 0, 0); form->addWidget(zoneName, 0, 1);
        form->addWidget(new QLabel("Severity (1–5)"), 0, 2); form->addWidget(severity, 0, 3);
        form->addWidget(new QLabel("People affected"), 1, 0); form->addWidget(people, 1, 1);
        form->addWidget(new QLabel("Food packets needed"), 1, 2); form->addWidget(foodNeed, 1, 3);
        form->addWidget(new QLabel("Water units needed"), 2, 0); form->addWidget(waterNeed, 2, 1);
        form->addWidget(new QLabel("Medical kits needed"), 2, 2); form->addWidget(medicalNeed, 2, 3);
        auto *add = button("＋ Add / Update Zone");
        form->addWidget(add, 3, 0, 1, 4);
        connect(add, &QPushButton::clicked, this, &MainWindow::addZone);
        l->addWidget(group);

        auto *info = new QLabel("Priority score = severity × 20 + population factor. Severity 5 represents the highest urgency.");
        info->setObjectName("hint");
        l->addWidget(info);
        auto *del = button("Remove Selected Zone", "dangerButton");
        connect(del, &QPushButton::clicked, this, &MainWindow::removeZone);
        l->addWidget(del, 0, Qt::AlignRight);
        auto *table = new QTableWidget(0, 7);
        table->setObjectName("monitorTable");
        table->setHorizontalHeaderLabels({"Zone", "Severity", "People", "Food Need", "Water Need", "Medical Need", "Priority"});
        configureTable(table);
        // The monitoring table is the second table widget; refresh locates it by object name.
        l->addWidget(table);
        return w;
    }

    QWidget *buildResources() {
        auto *w = new QWidget;
        auto *l = new QVBoxLayout(w);
        auto *title = new QLabel("Self-Adaptive Emergency Resource Optimization");
        title->setObjectName("sectionTitle");
        l->addWidget(title);

        auto *stock = new QGroupBox("Available central inventory");
        auto *form = new QGridLayout(stock);
        foodInput = new QSpinBox; foodInput->setRange(0, 10000000); foodInput->setValue(foodStock);
        waterInput = new QSpinBox; waterInput->setRange(0, 10000000); waterInput->setValue(waterStock);
        medicalInput = new QSpinBox; medicalInput->setRange(0, 10000000); medicalInput->setValue(medicalStock);
        form->addWidget(new QLabel("Food packets"), 0, 0); form->addWidget(foodInput, 0, 1);
        form->addWidget(new QLabel("Water units"), 0, 2); form->addWidget(waterInput, 0, 3);
        form->addWidget(new QLabel("Medical kits"), 0, 4); form->addWidget(medicalInput, 0, 5);
        auto *saveStock = button("Update Inventory");
        form->addWidget(saveStock, 0, 6);
        connect(saveStock, &QPushButton::clicked, this, [this]{
            foodStock = foodInput->value(); waterStock = waterInput->value(); medicalStock = medicalInput->value();
            saveData(); refreshAll();
        });
        l->addWidget(stock);

        auto *allocate = button("Run Smart Allocation");
        connect(allocate, &QPushButton::clicked, this, &MainWindow::allocateResources);
        l->addWidget(allocate, 0, Qt::AlignLeft);

        allocationTable = new QTableWidget(0, 10);
        allocationTable->setHorizontalHeaderLabels({"Zone", "Priority", "Food Given", "Food Shortage", "Water Given", "Water Shortage", "Medical Given", "Medical Shortage", "People", "Severity"});
        configureTable(allocationTable);
        l->addWidget(allocationTable);
        return w;
    }

    QWidget *buildRoutes() {
        auto *w = new QWidget;
        auto *l = new QVBoxLayout(w);
        auto *title = new QLabel("Intelligent Route Optimization & Mission Control");
        title->setObjectName("sectionTitle");
        l->addWidget(title);
        auto *group = new QGroupBox("Road network (distance can represent km or minutes)");
        auto *g = new QGridLayout(group);
        roadFrom = new QLineEdit; roadFrom->setPlaceholderText("From location");
        roadTo = new QLineEdit; roadTo->setPlaceholderText("To location");
        roadDistance = new QSpinBox; roadDistance->setRange(1, 1000000); roadDistance->setValue(5);
        auto *blocked = new QComboBox; blocked->addItems({"Open", "Blocked"});
        g->addWidget(new QLabel("From"), 0, 0); g->addWidget(roadFrom, 0, 1);
        g->addWidget(new QLabel("To"), 0, 2); g->addWidget(roadTo, 0, 3);
        g->addWidget(new QLabel("Distance"), 0, 4); g->addWidget(roadDistance, 0, 5);
        g->addWidget(new QLabel("Status"), 0, 6); g->addWidget(blocked, 0, 7);
        auto *addRoad = button("＋ Add Road");
        g->addWidget(addRoad, 0, 8);
        connect(addRoad, &QPushButton::clicked, this, [this, blocked]{
            QString a = roadFrom->text().trimmed(), b = roadTo->text().trimmed();
            if (a.isEmpty() || b.isEmpty() || a.compare(b, Qt::CaseInsensitive) == 0) {
                QMessageBox::warning(this, "Invalid road", "Enter two different location names."); return;
            }
            roads.push_back({a, b, roadDistance->value(), blocked->currentIndex() == 1});
            roadFrom->clear(); roadTo->clear(); saveData(); refreshAll();
        });
        l->addWidget(group);

        auto *routeGroup = new QGroupBox("Find shortest available route");
        auto *rg = new QHBoxLayout(routeGroup);
        routeFrom = new QComboBox; routeTo = new QComboBox;
        auto *find = button("Find Shortest Route");
        rg->addWidget(new QLabel("Start")); rg->addWidget(routeFrom);
        rg->addWidget(new QLabel("Destination")); rg->addWidget(routeTo);
        rg->addWidget(find);
        connect(find, &QPushButton::clicked, this, &MainWindow::findRoute);
        l->addWidget(routeGroup);

        roadTable = new QTableWidget(0, 4);
        roadTable->setHorizontalHeaderLabels({"From", "To", "Distance", "Road Status"});
        configureTable(roadTable);
        l->addWidget(roadTable);
        routeOutput = new QTextEdit; routeOutput->setReadOnly(true); routeOutput->setMaximumHeight(100);
        routeOutput->setPlaceholderText("Route result will appear here.");
        l->addWidget(routeOutput);
        return w;
    }

    QWidget *buildReports() {
        auto *w = new QWidget;
        auto *l = new QVBoxLayout(w);
        auto *title = new QLabel("Situation Reports");
        title->setObjectName("sectionTitle");
        l->addWidget(title);
        auto *generate = button("Generate Current Situation Report");
        connect(generate, &QPushButton::clicked, this, &MainWindow::generateReport);
        l->addWidget(generate, 0, Qt::AlignLeft);
        reportOutput = new QTextEdit;
        reportOutput->setReadOnly(true);
        l->addWidget(reportOutput);
        return w;
    }

    void configureTable(QTableWidget *t) {
        t->setEditTriggers(QAbstractItemView::NoEditTriggers);
        t->setSelectionBehavior(QAbstractItemView::SelectRows);
        t->setAlternatingRowColors(true);
        t->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
        t->verticalHeader()->setVisible(false);
        t->setMinimumHeight(210);
    }

    int priority(const Zone &z) const {
        return z.severity * 20 + qMin(20, z.people / 100);
    }

    void addZone() {
        QString name = zoneName->text().trimmed();
        if (name.isEmpty()) { QMessageBox::warning(this, "Missing name", "Enter a location name."); return; }
        int idx = -1;
        for (int i=0; i<zones.size(); ++i) if (zones[i].name.compare(name, Qt::CaseInsensitive)==0) idx=i;
        Zone z;
        z.name=name; z.severity=severity->value(); z.people=people->value();
        z.foodNeed=foodNeed->value(); z.waterNeed=waterNeed->value(); z.medicalNeed=medicalNeed->value();
        if (idx >= 0) zones[idx]=z; else zones.push_back(z);
        zoneName->clear(); saveData(); refreshAll();
        QMessageBox::information(this, "Saved", "Zone information has been saved.");
    }

    void removeZone() {
        auto *t = findChild<QTableWidget*>("monitorTable");
        if (!t || t->currentRow() < 0 || t->currentRow() >= zones.size()) {
            QMessageBox::information(this, "Select a zone", "Select a zone row first."); return;
        }
        zones.removeAt(t->currentRow()); saveData(); refreshAll();
    }

    void allocateResources() {
        for (auto &z : zones) z.foodAllocated = z.waterAllocated = z.medicalAllocated = 0;
        int f=foodStock, w=waterStock, m=medicalStock;
        QVector<int> order;
        for (int i=0;i<zones.size();++i) order.push_back(i);
        std::sort(order.begin(), order.end(), [this](int a,int b){ return priority(zones[a]) > priority(zones[b]); });
        for (int i : order) {
            Zone &z=zones[i];
            z.foodAllocated=qMin(f,z.foodNeed); f-=z.foodAllocated;
            z.waterAllocated=qMin(w,z.waterNeed); w-=z.waterAllocated;
            z.medicalAllocated=qMin(m,z.medicalNeed); m-=z.medicalAllocated;
        }
        saveData(); refreshAll();
        tabs->setCurrentIndex(2);
        QMessageBox::information(this, "Allocation complete", "Resources were allocated in descending priority order. Shortages are shown in the table.");
    }

    void findRoute() {
        QString start=routeFrom->currentText(), goal=routeTo->currentText();
        if (start.isEmpty() || goal.isEmpty() || start==goal) {
            QMessageBox::warning(this, "Choose locations", "Select two different locations."); return;
        }
        QMap<QString,int> dist;
        QMap<QString,QString> prev;
        QSet<QString> visited;
        QSet<QString> nodes;
        for (const auto &r: roads) { nodes.insert(r.from); nodes.insert(r.to); }
        for (const auto &z: zones) nodes.insert(z.name);
        for (const auto &n:nodes) dist[n]=std::numeric_limits<int>::max();
        dist[start]=0;
        while (visited.size() < nodes.size()) {
            QString u; int best=std::numeric_limits<int>::max();
            for (const auto &n:nodes) if (!visited.contains(n) && dist.value(n, std::numeric_limits<int>::max()) < best) {
                best=dist[n]; u=n;
            }
            if (u.isEmpty()) break;
            if (u==goal) break;
            visited.insert(u);
            for (const auto &r: roads) {
                if (r.blocked) continue;
                QString v; if (r.from==u) v=r.to; else if (r.to==u) v=r.from; else continue;
                int alt=dist[u]+r.distance;
                if (alt < dist.value(v, std::numeric_limits<int>::max())) { dist[v]=alt; prev[v]=u; }
            }
        }
        if (dist.value(goal, std::numeric_limits<int>::max()) == std::numeric_limits<int>::max()) {
            routeOutput->setText("No available route found. Check road connections or blocked-road status."); return;
        }
        QStringList path; QString cur=goal; path.prepend(cur);
        while (prev.contains(cur)) { cur=prev[cur]; path.prepend(cur); }
        routeOutput->setText("SHORTEST ROUTE: " + path.join("  →  ") +
                             "\nTotal distance / travel cost: " + QString::number(dist[goal]) +
                             "\nBlocked roads were excluded from the calculation.");
    }

    void refreshAll() {
        if (zoneMetric) zoneMetric->setText(QString::number(zones.size()));
        int totalPeople=0; for (const auto &z:zones) totalPeople+=z.people;
        if (peopleMetric) peopleMetric->setText(QString::number(totalPeople));
        if (foodMetric) foodMetric->setText(QString::number(foodStock));
        if (waterMetric) waterMetric->setText(QString::number(waterStock));

        if (zoneTable) {
            zoneTable->setRowCount(zones.size());
            for (int i=0;i<zones.size();++i) {
                const auto &z=zones[i];
                QStringList vals={z.name,QString::number(z.severity),QString::number(z.people),
                    QString::number(z.foodNeed),QString::number(z.waterNeed),QString::number(z.medicalNeed),QString::number(priority(z))};
                for(int c=0;c<vals.size();++c) zoneTable->setItem(i,c,new QTableWidgetItem(vals[c]));
            }
        }
        auto *mt=findChild<QTableWidget*>("monitorTable");
        if (mt) {
            mt->setRowCount(zones.size());
            for(int i=0;i<zones.size();++i) {
                const auto &z=zones[i];
                QStringList vals={z.name,QString::number(z.severity),QString::number(z.people),QString::number(z.foodNeed),
                    QString::number(z.waterNeed),QString::number(z.medicalNeed),QString::number(priority(z))};
                for(int c=0;c<vals.size();++c) mt->setItem(i,c,new QTableWidgetItem(vals[c]));
            }
        }
        if (allocationTable) {
            allocationTable->setRowCount(zones.size());
            for(int i=0;i<zones.size();++i) {
                const auto &z=zones[i];
                QStringList vals={z.name,QString::number(priority(z)),QString::number(z.foodAllocated),
                    QString::number(z.foodNeed-z.foodAllocated),QString::number(z.waterAllocated),
                    QString::number(z.waterNeed-z.waterAllocated),QString::number(z.medicalAllocated),
                    QString::number(z.medicalNeed-z.medicalAllocated),QString::number(z.people),QString::number(z.severity)};
                for(int c=0;c<vals.size();++c) allocationTable->setItem(i,c,new QTableWidgetItem(vals[c]));
            }
        }
        if (roadTable) {
            roadTable->setRowCount(roads.size());
            for(int i=0;i<roads.size();++i) {
                const auto &r=roads[i];
                QStringList vals={r.from,r.to,QString::number(r.distance),r.blocked?"BLOCKED":"OPEN"};
                for(int c=0;c<vals.size();++c) roadTable->setItem(i,c,new QTableWidgetItem(vals[c]));
            }
        }
        if (routeFrom && routeTo) {
            QString oldFrom=routeFrom->currentText(), oldTo=routeTo->currentText();
            routeFrom->clear(); routeTo->clear();
            QSet<QString> names;
            for(const auto &z:zones) names.insert(z.name);
            for(const auto &r:roads){names.insert(r.from);names.insert(r.to);}
            QStringList sorted=names.values(); sorted.sort(Qt::CaseInsensitive);
            routeFrom->addItems(sorted); routeTo->addItems(sorted);
            routeFrom->setCurrentText(oldFrom); routeTo->setCurrentText(oldTo);
        }
        if (foodInput) { foodInput->setValue(foodStock); waterInput->setValue(waterStock); medicalInput->setValue(medicalStock); }
    }

    void generateReport() {
        QString out="ARES — EMERGENCY SITUATION REPORT\nGenerated: "+QDateTime::currentDateTime().toString("dd MMM yyyy hh:mm")+"\n";
        out+="====================================================\n";
        out+=QString("Zones registered: %1\nPeople affected: %2\nCentral stock — Food: %3 | Water: %4 | Medical kits: %5\n\n")
            .arg(zones.size()).arg([this]{int n=0;for(const auto&z:zones)n+=z.people;return n;}())
            .arg(foodStock).arg(waterStock).arg(medicalStock);
        QVector<Zone> sorted=zones;
        std::sort(sorted.begin(),sorted.end(),[this](const Zone&a,const Zone&b){return priority(a)>priority(b);});
        out+="ZONE PRIORITIES AND CURRENT ALLOCATION\n";
        for(const auto &z:sorted) {
            out+=QString("\n%1 | Severity %2 | People %3 | Priority %4\n")
                .arg(z.name).arg(z.severity).arg(z.people).arg(priority(z));
            out+=QString("Food: %1/%2 supplied (shortage %3)\n").arg(z.foodAllocated).arg(z.foodNeed).arg(z.foodNeed-z.foodAllocated);
            out+=QString("Water: %1/%2 supplied (shortage %3)\n").arg(z.waterAllocated).arg(z.waterNeed).arg(z.waterNeed-z.waterAllocated);
            out+=QString("Medical: %1/%2 supplied (shortage %3)\n").arg(z.medicalAllocated).arg(z.medicalNeed).arg(z.medicalNeed-z.medicalAllocated);
        }
        out+="\nROAD NETWORK\n";
        for(const auto&r:roads) out+=QString("%1 ↔ %2 | %3 | %4\n").arg(r.from).arg(r.to).arg(r.distance).arg(r.blocked?"BLOCKED":"OPEN");
        out+="\nNote: This is a decision-support calculation based on the data entered by the operator. Verify field conditions before dispatch.";
        reportOutput->setPlainText(out);
        QFile f(QCoreApplication::applicationDirPath()+"/ARES_Situation_Report.txt");
        if(f.open(QIODevice::WriteOnly|QIODevice::Text)){f.write(out.toUtf8());f.close();}
    }

    void saveData() {
        QJsonObject root;
        root["foodStock"]=foodStock; root["waterStock"]=waterStock; root["medicalStock"]=medicalStock;
        QJsonArray za;
        for(const auto&z:zones){
            QJsonObject o; o["name"]=z.name;o["severity"]=z.severity;o["people"]=z.people;
            o["foodNeed"]=z.foodNeed;o["waterNeed"]=z.waterNeed;o["medicalNeed"]=z.medicalNeed;
            o["foodAllocated"]=z.foodAllocated;o["waterAllocated"]=z.waterAllocated;o["medicalAllocated"]=z.medicalAllocated;
            za.append(o);
        }
        root["zones"]=za;
        QJsonArray ra;
        for(const auto&r:roads){QJsonObject o;o["from"]=r.from;o["to"]=r.to;o["distance"]=r.distance;o["blocked"]=r.blocked;ra.append(o);}
        root["roads"]=ra;
        QFile f(dataPath());
        if(f.open(QIODevice::WriteOnly)){f.write(QJsonDocument(root).toJson(QJsonDocument::Indented));f.close();}
    }

    void loadData() {
        QFile f(dataPath());
        if(!f.open(QIODevice::ReadOnly)) return;
        QJsonParseError err; auto doc=QJsonDocument::fromJson(f.readAll(),&err); f.close();
        if(err.error!=QJsonParseError::NoError || !doc.isObject()) return;
        auto root=doc.object();
        foodStock=root.value("foodStock").toInt(1000);waterStock=root.value("waterStock").toInt(1500);medicalStock=root.value("medicalStock").toInt(300);
        for(const auto&v:root.value("zones").toArray()){
            auto o=v.toObject();Zone z;z.name=o["name"].toString();z.severity=o["severity"].toInt();z.people=o["people"].toInt();
            z.foodNeed=o["foodNeed"].toInt();z.waterNeed=o["waterNeed"].toInt();z.medicalNeed=o["medicalNeed"].toInt();
            z.foodAllocated=o["foodAllocated"].toInt();z.waterAllocated=o["waterAllocated"].toInt();z.medicalAllocated=o["medicalAllocated"].toInt();
            zones.push_back(z);
        }
        for(const auto&v:root.value("roads").toArray()){
            auto o=v.toObject();roads.push_back({o["from"].toString(),o["to"].toString(),o["distance"].toInt(),o["blocked"].toBool()});
        }
    }

    void applyStyle() {
        setStyleSheet(R"(
            QMainWindow, QWidget { background:#101827; color:#e8eef8; font-family:"Segoe UI"; font-size:10pt; }
            QLabel#brand { color:#53d6c7; font-size:25pt; font-weight:800; letter-spacing:2px; }
            QLabel#subtitle { color:#91a4bd; font-size:9pt; font-weight:600; }
            QLabel#online { color:#62d6a5; font-weight:700; }
            QLabel#sectionTitle { color:#f3f7ff; font-size:19pt; font-weight:700; padding:10px 2px; }
            QLabel#subTitle { color:#b9c9dc; font-size:12pt; font-weight:700; padding-top:10px; }
            QLabel#hint { color:#9fb1c8; padding:8px; background:#172438; border-radius:7px; }
            QFrame#metricCard { background:#1a2a40; border:1px solid #2b405c; border-radius:12px; min-height:95px; }
            QLabel#metricCaption { color:#91a9c4; font-size:8pt; font-weight:700; }
            QLabel#metricValue { color:#58d9ca; font-size:23pt; font-weight:800; }
            QTabWidget::pane { border:1px solid #2b405c; border-radius:8px; top:-1px; }
            QTabBar::tab { background:#172438; color:#aabbd0; padding:12px 17px; margin-right:3px; border-top-left-radius:7px; border-top-right-radius:7px; }
            QTabBar::tab:selected { background:#245a68; color:white; font-weight:700; }
            QLineEdit, QSpinBox, QComboBox, QTextEdit, QTableWidget { background:#152337; border:1px solid #30445f; border-radius:6px; padding:7px; selection-background-color:#267f83; }
            QHeaderView::section { background:#20354e; color:#d8e6f5; padding:8px; border:0; font-weight:700; }
            QTableWidget { gridline-color:#2a3c53; alternate-background-color:#192a40; }
            QGroupBox { border:1px solid #30445f; border-radius:8px; margin-top:12px; padding:12px; font-weight:700; color:#8fe3dc; }
            QGroupBox::title { subcontrol-origin:margin; left:12px; padding:0 5px; }
            QPushButton { background:#247d83; color:white; border:0; border-radius:7px; padding:10px 16px; font-weight:700; }
            QPushButton:hover { background:#2d999d; }
            QPushButton#dangerButton { background:#9d4552; }
            QPushButton#dangerButton:hover { background:#bd5362; }
        )");
    }
};

int main(int argc, char *argv[]) {
    QApplication app(argc, argv);
    MainWindow window;
    window.show();
    return app.exec();
}

#include "main.moc"
