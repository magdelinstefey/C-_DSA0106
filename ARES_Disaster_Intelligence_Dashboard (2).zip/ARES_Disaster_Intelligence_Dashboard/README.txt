ARES – DISASTER INTELLIGENCE & EMERGENCY RESOURCE CONTROL
=========================================================

WHAT THIS PROJECT DOES
----------------------
ARES is a C++ desktop decision-support dashboard. It calculates results from
the information entered by the operator; it does not display fixed demo output.

MODULE 1 – DISASTER MONITORING
* Register or update affected locations.
* Enter severity (1 to 5), affected population and resource needs.
* Calculate a priority score: severity * 20 + min(20, people / 100).

MODULE 2 – RESOURCE OPTIMIZATION
* Set the available food, water and medical inventory.
* Run Smart Allocation.
* The application sorts zones by priority and allocates available stock.
* It shows supplied quantities and remaining shortages for each zone.

MODULE 3 – ROUTE OPTIMIZATION
* Enter road connections and distances.
* Mark a road Open or Blocked.
* Dijkstra's shortest-path algorithm finds the lowest-cost available route.
* Blocked roads are excluded.

REPORTS AND DATA
* Zone, road, inventory and allocation data are saved in ares_data.json
  beside the running application.
* A situation report can be generated and saved as ARES_Situation_Report.txt.

IMPORTANT LIMITATION
--------------------
This is an offline decision-support prototype. It uses operator-entered data.
It does not independently detect disasters, fetch live weather/traffic data,
verify road conditions, or physically dispatch supplies. Validate field
conditions and have an authorized human confirm decisions before dispatch.

REQUIREMENTS
------------
* Windows 10/11 (or another OS supported by Qt 6)
* C++ compiler supported by Qt (MinGW or MSVC on Windows)
* CMake
* Qt 6 with the Widgets component

BUILD USING QT CREATOR (EASIEST)
--------------------------------
1. Install Qt 6 using the official Qt online installer.
2. During installation select a Qt 6 kit matching your compiler
   (for example, MinGW 64-bit) and install Qt Creator and CMake tools.
3. Extract this ZIP to a normal folder.
4. Open Qt Creator.
5. Choose File > Open File or Project and select CMakeLists.txt.
6. Select the matching Desktop kit when prompted.
7. Click Configure Project, then Build, then Run.

BUILD USING VS CODE
-------------------
1. Install Qt 6 and a matching compiler (MinGW or MSVC), plus CMake.
2. Install the VS Code extensions: C/C++ and CMake Tools.
3. Extract this ZIP and open the extracted folder in VS Code.
4. Open the Command Palette (Ctrl+Shift+P) and choose:
   CMake: Select a Kit
5. Select the compiler that matches the Qt kit you installed.
6. Choose the Qt 6 CMake package path if CMake cannot find Qt:
   configure with -DCMAKE_PREFIX_PATH="PATH_TO_QT_KIT"
   Example (adjust the path and kit folder to your installation):
   cmake -S . -B build -DCMAKE_PREFIX_PATH="C:/Qt/6.x.x/mingw_64"
   cmake --build build
7. Run the generated ARES executable from the build folder.
   The exact executable path depends on the selected compiler and build type.

FIRST TEST (TRY THESE VALUES)
-----------------------------
In Disaster Monitoring add:
* Zone Alpha: severity 5, people 800, food 700, water 500, medical 120
* Zone Beta: severity 3, people 500, food 500, water 400, medical 80
* Zone Gamma: severity 4, people 300, food 300, water 250, medical 60

In Resource Allocation set:
* Food = 1000
* Water = 900
* Medical kits = 200
Click "Run Smart Allocation". The table calculates the allocations and
shortages from these values.

In Route Optimization add roads:
* Zone Alpha to Zone Beta, distance 8, Open
* Zone Beta to Zone Gamma, distance 4, Open
* Zone Alpha to Zone Gamma, distance 20, Open
Find route from Zone Alpha to Zone Gamma. The shortest route should be
Zone Alpha -> Zone Beta -> Zone Gamma, total distance 12.

NOTES
-----
* The application starts with empty zone and road data; add your own data.
* All distances use the same unit chosen by the operator (e.g. km or minutes).
* Allocation is a transparent priority-first greedy method, not a claim of
  globally optimal logistics planning.
